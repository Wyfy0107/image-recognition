const aws = require('aws-sdk')

const rekognition = new aws.Rekognition()
// const s3 = new aws.S3()

// const uploadImage = (object, labels) => {}

const detectLabels = async (bucketName, key) => {
  const params = {
    Image: {
      S3Object: {
        Bucket: bucketName,
        Name: key,
      },
    },
    MaxLabels: '10',
    MinConfidence: '50',
  }

  const data = await rekognition
    .detectLabels(params)
    .promise()
    .then(data => data.Labels)

  console.log('labels', labels)
  return data
}

const processRecord = async record => {
  const bucketName = record.s3.bucket.name
  const key = record.s3.object.key
  const labels = await detectLabels(bucketName, key)
  return labels
}

exports.lambda_handler = async (event, context, callback) => {
  try {
    const labels = event.Records.map(processRecord)
    callback(null, labels)
  } catch (err) {
    console.error(err)
    callback(err)
  }
}
